-- Sportwagenvermietung – PostgreSQL 16 Schema (Entwurf v0.1)
-- Geldbeträge immer in Cent (BIGINT). Zeiträume als tstzrange.

CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ───────────── Enums ─────────────
CREATE TYPE user_role          AS ENUM ('customer', 'staff', 'admin');
CREATE TYPE screening_status   AS ENUM ('not_started', 'pending', 'verified', 'rejected', 'manual_review');
CREATE TYPE vehicle_status     AS ENUM ('active', 'maintenance', 'sold', 'archived');
CREATE TYPE booking_status     AS ENUM ('hold', 'pending_payment', 'confirmed', 'contract_signed',
                                        'active', 'returned', 'settled', 'cancelled', 'no_show');
CREATE TYPE payment_kind       AS ENUM ('deposit_down_payment', 'full_payment', 'security_deposit_hold',
                                        'security_deposit_capture', 'security_deposit_release', 'charge', 'refund');
CREATE TYPE payment_status     AS ENUM ('pending', 'authorized', 'succeeded', 'failed', 'canceled', 'refunded');
CREATE TYPE charge_status      AS ENUM ('open', 'paid', 'settled_from_deposit', 'waived', 'cancelled');
CREATE TYPE charge_type        AS ENUM ('extra_km', 'fuel', 'late_return', 'damage', 'cleaning', 'fine', 'other');
CREATE TYPE inspection_type    AS ENUM ('handover', 'return');
CREATE TYPE damage_severity    AS ENUM ('minor', 'moderate', 'major');
CREATE TYPE contract_status    AS ENUM ('draft', 'sent', 'signed', 'void');

-- ───────────── Users ─────────────
CREATE TABLE users (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role             user_role NOT NULL DEFAULT 'customer',
  email            TEXT NOT NULL UNIQUE,
  phone            TEXT,
  first_name       TEXT NOT NULL,
  last_name        TEXT NOT NULL,
  birth_date       DATE,
  company_name     TEXT,
  vat_id           TEXT,
  address_line1    TEXT,
  address_line2    TEXT,
  postal_code      TEXT,
  city             TEXT,
  country_code     CHAR(2),
  stripe_customer_id TEXT UNIQUE,
  screening_status screening_status NOT NULL DEFAULT 'not_started',
  blacklisted      BOOLEAN NOT NULL DEFAULT FALSE,
  blacklist_reason TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ausweis-/Führerscheinprüfung (sensible Daten: Dateien verschlüsselt im Object Store)
CREATE TABLE identity_checks (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider           TEXT NOT NULL,                 -- z.B. 'stripe_identity', 'veriff', 'hyghcheck'
  provider_reference TEXT,
  id_document_key    TEXT,                          -- Object-Store-Key (verschlüsselt)
  license_key        TEXT,
  license_class      TEXT,
  license_issued_on  DATE,
  license_valid_until DATE,
  status             screening_status NOT NULL DEFAULT 'pending',
  result_payload     JSONB,                         -- Rohergebnis des Providers
  checked_at         TIMESTAMPTZ,
  delete_after       DATE,                          -- DSGVO-Löschfrist
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ───────────── Vehicles ─────────────
CREATE TABLE vehicles (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  make               TEXT NOT NULL,                 -- Porsche, Lamborghini, Ferrari
  model              TEXT NOT NULL,
  variant            TEXT,
  year               INT,
  license_plate      TEXT NOT NULL UNIQUE,
  vin                TEXT UNIQUE,
  color              TEXT,
  power_ps           INT,
  fuel_type          TEXT,
  tank_capacity_l    NUMERIC(5,1),
  min_driver_age     INT NOT NULL DEFAULT 25,
  min_license_years  INT NOT NULL DEFAULT 3,
  deposit_cents      BIGINT NOT NULL,               -- Kaution
  base_weekday_cents BIGINT NOT NULL,               -- Preis/Tag Mo–Do
  weekend_surcharge_cents BIGINT NOT NULL DEFAULT 0,-- Zuschlag pro Tag Fr–So
  vehicle_status     vehicle_status NOT NULL DEFAULT 'active',
  telematics_device_id TEXT,
  odometer_km        INT NOT NULL DEFAULT 0,
  images             JSONB NOT NULL DEFAULT '[]',
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Kilometerpakete je Fahrzeug
CREATE TABLE km_packages (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id       UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  name             TEXT NOT NULL,                   -- z.B. '200 km/Tag'
  km_per_day       INT,                             -- NULL = unlimited
  price_per_day_cents BIGINT NOT NULL DEFAULT 0,
  extra_km_cents   BIGINT NOT NULL,                 -- Preis je Mehr-Kilometer
  unlimited        BOOLEAN NOT NULL DEFAULT FALSE
);

-- Extras (Zusatzfahrer, Vollkasko-Reduzierung, Lieferung, GoPro, ...)
CREATE TABLE extras (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code         TEXT NOT NULL UNIQUE,                -- 'additional_driver', 'insurance_reduction', 'delivery', 'gopro'
  name         TEXT NOT NULL,
  pricing_mode TEXT NOT NULL CHECK (pricing_mode IN ('per_day', 'per_booking', 'per_km')),
  price_cents  BIGINT NOT NULL,
  active       BOOLEAN NOT NULL DEFAULT TRUE
);

-- Saisonale/Sonder-Preisregeln (Feiertage, Events, Hauptsaison)
CREATE TABLE price_rules (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id   UUID REFERENCES vehicles(id) ON DELETE CASCADE, -- NULL = alle
  name         TEXT NOT NULL,
  valid_during DATERANGE NOT NULL,
  multiplier   NUMERIC(5,3) NOT NULL DEFAULT 1.000,
  min_days     INT,
  priority     INT NOT NULL DEFAULT 0
);

-- Mengenrabatt je Mietdauer
CREATE TABLE duration_discounts (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  min_days    INT NOT NULL,
  percent     NUMERIC(5,2) NOT NULL CHECK (percent >= 0 AND percent <= 100)
);

-- ───────────── Bookings ─────────────
CREATE TABLE bookings (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_number   TEXT NOT NULL UNIQUE,            -- z.B. 'B-2026-000123'
  user_id          UUID NOT NULL REFERENCES users(id),
  vehicle_id       UUID NOT NULL REFERENCES vehicles(id),
  km_package_id    UUID REFERENCES km_packages(id),
  rental_period    TSTZRANGE NOT NULL,              -- [Abholung, Rückgabe)
  blocked_period   TSTZRANGE NOT NULL,              -- inkl. Puffer (Reinigung etc.)
  status           booking_status NOT NULL DEFAULT 'hold',
  hold_expires_at  TIMESTAMPTZ,
  included_km      INT,
  extra_km_cents   BIGINT,
  pricing_snapshot JSONB NOT NULL,                  -- komplette Preisaufschlüsselung zum Buchungszeitpunkt
  total_cents      BIGINT NOT NULL,
  tax_rate_percent NUMERIC(5,2) NOT NULL,
  deposit_cents    BIGINT NOT NULL,
  delivery_address TEXT,
  pickup_address   TEXT,
  cancelled_at     TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Doppelbuchungsschutz direkt in der Datenbank:
  CONSTRAINT no_overlapping_bookings
    EXCLUDE USING gist (vehicle_id WITH =, blocked_period WITH &&)
    WHERE (status NOT IN ('cancelled', 'no_show'))
);
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_bookings_status ON bookings(status);

CREATE TABLE booking_extras (
  booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  extra_id   UUID NOT NULL REFERENCES extras(id),
  quantity   INT NOT NULL DEFAULT 1,
  price_cents BIGINT NOT NULL,
  PRIMARY KEY (booking_id, extra_id)
);

CREATE TABLE booking_drivers (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id  UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  user_id     UUID REFERENCES users(id),
  first_name  TEXT NOT NULL,
  last_name   TEXT NOT NULL,
  is_primary  BOOLEAN NOT NULL DEFAULT FALSE,
  identity_check_id UUID REFERENCES identity_checks(id)
);

-- ───────────── Payments & Schuldenbuch ─────────────
CREATE TABLE payments (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id         UUID NOT NULL REFERENCES bookings(id),
  charge_id          UUID,                          -- FK unten
  kind               payment_kind NOT NULL,
  status             payment_status NOT NULL DEFAULT 'pending',
  amount_cents       BIGINT NOT NULL,
  currency           CHAR(3) NOT NULL DEFAULT 'EUR',
  provider           TEXT NOT NULL,                 -- 'stripe' | 'mollie'
  provider_payment_id TEXT,                         -- PaymentIntent-ID etc.
  idempotency_key    TEXT UNIQUE,
  authorized_until   TIMESTAMPTZ,                   -- Ablauf der Pre-Auth
  raw_payload        JSONB,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_booking ON payments(booking_id);

-- "Schuldenbuch": offene Posten / Nachberechnungen
CREATE TABLE charges (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id    UUID NOT NULL REFERENCES bookings(id),
  user_id       UUID NOT NULL REFERENCES users(id),
  type          charge_type NOT NULL,
  description   TEXT NOT NULL,
  amount_cents  BIGINT NOT NULL,
  tax_rate_percent NUMERIC(5,2) NOT NULL DEFAULT 0, -- Schadenersatz i.d.R. kein Entgelt → steuerlich prüfen
  status        charge_status NOT NULL DEFAULT 'open',
  due_date      DATE,
  inspection_id UUID,
  damage_id     UUID,
  created_by    UUID REFERENCES users(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  settled_at    TIMESTAMPTZ
);
ALTER TABLE payments ADD CONSTRAINT fk_payments_charge FOREIGN KEY (charge_id) REFERENCES charges(id);

-- ───────────── Inspections & Damages ─────────────
CREATE TABLE inspections (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id       UUID NOT NULL REFERENCES bookings(id),
  type             inspection_type NOT NULL,
  odometer_km      INT NOT NULL,
  fuel_level_percent INT NOT NULL CHECK (fuel_level_percent BETWEEN 0 AND 100),
  notes            TEXT,
  renter_signature_key TEXT,
  staff_signature_key  TEXT,
  staff_user_id    UUID REFERENCES users(id),
  protocol_pdf_key TEXT,
  completed_at     TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (booking_id, type)
);

CREATE TABLE inspection_photos (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_id UUID NOT NULL REFERENCES inspections(id) ON DELETE CASCADE,
  slot          TEXT NOT NULL,                      -- 'odometer','fuel','front','rear','left','right','wheel_fl',...
  storage_key   TEXT NOT NULL,
  sha256        TEXT NOT NULL,
  taken_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  geo_lat       NUMERIC(9,6),
  geo_lng       NUMERIC(9,6)
);

CREATE TABLE damages (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id     UUID NOT NULL REFERENCES vehicles(id),
  booking_id     UUID REFERENCES bookings(id),      -- Verursachende Buchung (NULL = Vorschaden)
  inspection_id  UUID REFERENCES inspections(id),   -- Erfassung
  user_id        UUID REFERENCES users(id),         -- verantwortlicher Mieter (für Schadenhistorie)
  zone           TEXT NOT NULL,                     -- Zone im 360°-Schema, z.B. 'front_bumper'
  x_percent      NUMERIC(5,2),                      -- Position im Schema
  y_percent      NUMERIC(5,2),
  severity       damage_severity NOT NULL,
  description    TEXT,
  photo_keys     JSONB NOT NULL DEFAULT '[]',
  repair_cost_cents BIGINT,
  repaired_at    TIMESTAMPTZ,
  pre_existing   BOOLEAN NOT NULL DEFAULT FALSE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE charges ADD CONSTRAINT fk_charges_damage FOREIGN KEY (damage_id) REFERENCES damages(id);
ALTER TABLE charges ADD CONSTRAINT fk_charges_inspection FOREIGN KEY (inspection_id) REFERENCES inspections(id);

-- ───────────── Contracts ─────────────
CREATE TABLE contracts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id        UUID NOT NULL REFERENCES bookings(id),
  version           INT NOT NULL DEFAULT 1,
  status            contract_status NOT NULL DEFAULT 'draft',
  template_version  TEXT NOT NULL,
  pdf_key           TEXT NOT NULL,                  -- unsigniertes PDF
  signed_pdf_key    TEXT,                           -- signiertes PDF/A
  document_sha256   TEXT NOT NULL,
  signature_provider TEXT,
  signature_level   TEXT,                           -- 'SES' | 'AES' | 'QES'
  signed_at         TIMESTAMPTZ,
  signer_ip         INET,
  signer_user_agent TEXT,
  audit_trail       JSONB,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (booking_id, version)
);

-- ───────────── Invoices (GoBD: unveränderbar) ─────────────
CREATE TABLE invoices (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number TEXT NOT NULL UNIQUE,              -- lückenloser Nummernkreis
  booking_id     UUID REFERENCES bookings(id),
  user_id        UUID NOT NULL REFERENCES users(id),
  kind           TEXT NOT NULL CHECK (kind IN ('quote','confirmation','invoice','credit_note')),
  issued_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  net_cents      BIGINT NOT NULL,
  tax_cents      BIGINT NOT NULL,
  gross_cents    BIGINT NOT NULL,
  lines          JSONB NOT NULL,
  pdf_key        TEXT NOT NULL,
  pdf_sha256     TEXT NOT NULL,
  cancels_invoice_id UUID REFERENCES invoices(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Unveränderlichkeit: Updates/Deletes auf ausgestellte Rechnungen verhindern
CREATE OR REPLACE FUNCTION forbid_invoice_change() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'Rechnungen sind unveränderbar (GoBD). Bitte Storno/Gutschrift erstellen.';
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_invoices_immutable
  BEFORE UPDATE OR DELETE ON invoices
  FOR EACH ROW EXECUTE FUNCTION forbid_invoice_change();

-- ───────────── Audit-Log ─────────────
CREATE TABLE audit_log (
  id          BIGSERIAL PRIMARY KEY,
  actor_id    UUID REFERENCES users(id),
  action      TEXT NOT NULL,                        -- z.B. 'immobilizer.activate','deposit.capture'
  entity_type TEXT NOT NULL,
  entity_id   UUID,
  details     JSONB,
  ip          INET,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
