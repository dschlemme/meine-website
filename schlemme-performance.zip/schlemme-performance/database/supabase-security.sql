-- Nach schema.sql ausführen, nur bei Supabase. Direkter öffentlicher API-Zugriff ist nicht erforderlich.
DO $$ DECLARE t record; BEGIN
 FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
  EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t.tablename);
  EXECUTE format('REVOKE ALL ON TABLE public.%I FROM anon, authenticated', t.tablename);
 END LOOP;
END $$;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon, authenticated;
