-- Optionale Beispieldaten; keine echten Fahrzeugpreise.
INSERT INTO vehicles (id,make,model,license_plate,deposit_cents,base_weekday_cents,weekend_surcharge_cents)
VALUES ('11111111-1111-4111-8111-111111111111','Porsche','911','DEMO-911',500000,80000,20000) ON CONFLICT DO NOTHING;
INSERT INTO km_packages (id,vehicle_id,name,km_per_day,price_per_day_cents,extra_km_cents)
VALUES ('22222222-2222-4222-8222-222222222222','11111111-1111-4111-8111-111111111111','200 km/Tag',200,5000,300) ON CONFLICT DO NOTHING;
INSERT INTO extras (code,name,pricing_mode,price_cents) VALUES ('gopro','GoPro-Paket','per_day',3000),('delivery','Lieferung','per_booking',15000) ON CONFLICT DO NOTHING;
