import { Pool } from 'pg';
export const demo = process.env.DEMO_MODE === 'true';
const ca = process.env.DATABASE_CA_CERT?.replace(/\\n/g, '\n');
export const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 2, connectionTimeoutMillis: 8000, idleTimeoutMillis: 10000, ssl: { rejectUnauthorized: true, ...(ca ? { ca } : {}) } });
pool.on('error', () => console.error('Database idle connection error'));
export function requireDatabase() { if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL fehlt.'); }
