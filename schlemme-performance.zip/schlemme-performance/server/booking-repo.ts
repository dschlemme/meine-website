import type { Extra, KmPackage, PriceRule, DurationDiscount, VehiclePricing } from '../src/lib/pricing';

import { pool } from './db';

/** Pufferzeit vor/nach jeder Miete (Reinigung, Übergabe). */
export const BUFFER_HOURS = 3;

export async function isVehicleAvailable(vehicleId: string, start: Date, end: Date): Promise<boolean> {
  const { rows } = await pool.query<{ available: boolean }>(
    `SELECT
       EXISTS (SELECT 1 FROM vehicles WHERE id = $1 AND vehicle_status = 'active')
       AND NOT EXISTS (
         SELECT 1 FROM bookings
         WHERE vehicle_id = $1
           AND status NOT IN ('cancelled', 'no_show')
           AND NOT (status = 'hold' AND hold_expires_at < now())
           AND blocked_period && tstzrange(
                 $2::timestamptz - make_interval(hours => $4),
                 $3::timestamptz + make_interval(hours => $4), '[)')
       ) AS available`,
    [vehicleId, start.toISOString(), end.toISOString(), BUFFER_HOURS],
  );
  return rows[0]?.available ?? false;
}

export async function loadPricingData(vehicleId: string, kmPackageId: string, extraCodes: string[]) {
  const [v, k, e, r, d] = await Promise.all([
    pool.query(`SELECT id, base_weekday_cents, weekend_surcharge_cents, deposit_cents FROM vehicles WHERE id = $1 AND vehicle_status = 'active'`, [vehicleId]),
    pool.query(`SELECT * FROM km_packages WHERE id = $1 AND vehicle_id = $2`, [kmPackageId, vehicleId]),
    pool.query(`SELECT * FROM extras WHERE active AND code = ANY($1)`, [extraCodes]),
    pool.query(
      `SELECT name, lower(valid_during)::text AS valid_from, upper(valid_during)::text AS valid_until,
              multiplier::float AS multiplier, priority, vehicle_id, min_days
       FROM price_rules WHERE vehicle_id IS NULL OR vehicle_id = $1`, [vehicleId]),
    pool.query(`SELECT min_days, percent::float AS percent FROM duration_discounts`),
  ]);

  if (!v.rows[0] || !k.rows[0]) return null;

  if (e.rows.length !== new Set(extraCodes).size) return null;
  const vehicle: VehiclePricing = {
    id: v.rows[0].id,
    baseWeekdayCents: Number(v.rows[0].base_weekday_cents),
    weekendSurchargeCents: Number(v.rows[0].weekend_surcharge_cents),
    depositCents: Number(v.rows[0].deposit_cents),
  };
  const kmPackage: KmPackage = {
    id: k.rows[0].id,
    name: k.rows[0].name,
    kmPerDay: k.rows[0].km_per_day,
    unlimited: k.rows[0].unlimited,
    pricePerDayCents: Number(k.rows[0].price_per_day_cents),
    extraKmCents: Number(k.rows[0].extra_km_cents),
  };
  const extras: Extra[] = e.rows.map((x) => ({
    code: x.code, name: x.name, pricingMode: x.pricing_mode, priceCents: Number(x.price_cents),
  }));
  const rules: PriceRule[] = r.rows.map((x) => ({
    name: x.name, validFrom: x.valid_from, validUntil: x.valid_until, multiplier: x.multiplier,
    priority: x.priority, vehicleId: x.vehicle_id, minDays: x.min_days,
  }));
  const discounts: DurationDiscount[] = d.rows.map((x) => ({ minDays: x.min_days, percent: x.percent }));

  return { vehicle, kmPackage, extras, rules, discounts };
}
