export const vehicle = { id: '11111111-1111-4111-8111-111111111111', baseWeekdayCents: 80000, weekendSurchargeCents: 20000, depositCents: 500000 };
export const kmPackage = { id: '22222222-2222-4222-8222-222222222222', name: '200 km/Tag', kmPerDay: 200, unlimited: false, pricePerDayCents: 5000, extraKmCents: 300 };
export const extras = [{ code: 'gopro', name: 'GoPro-Paket', pricingMode: 'per_day' as const, priceCents: 3000 }, { code: 'delivery', name: 'Lieferung', pricingMode: 'per_booking' as const, priceCents: 15000 }];
export const catalog = { demo: true, vehicles: [{ id: vehicle.id, name: 'Porsche 911 · Demo', kmPackages: [kmPackage] }], extras: extras.map(x => ({ ...x, hint: `${(x.priceCents/100).toFixed(2)} € / ${x.pricingMode === 'per_day' ? 'Tag' : 'Buchung'}` })) };
