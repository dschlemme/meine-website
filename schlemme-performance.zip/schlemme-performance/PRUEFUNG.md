# Durchgeführte Prüfungen

- TypeScript-Prüfung ohne Fehler.
- Vite-Produktionsbuild erfolgreich.
- Alle sieben ursprünglichen Pricing-Testfälle erfolgreich.
- Demo-API geprüft: Katalog, erfolgreicher Preis, ungültiger Zeitraum, unbekanntes Extra, HTTP-Methode und Anfragevalidierung.

Keine Live-Datenbank und kein Netlify-Konto verbunden; SQL-Ausführung, TLS-Verbindung und tatsächlicher Netlify-Deploy sind daher noch nicht geprüft. Prüfung mit Node.js 24; Projektvorgabe mindestens Node.js 22.12.

Abhängigkeiten wurden zur Prüfung mit pnpm heruntergeladen. Dessen Schutz blockierte die Installationsskripte einiger Pakete; TypeScript, Vite und die Tests liefen mit den bereitgestellten Binärdateien dennoch erfolgreich. Die Netlify-CLI-Entwicklungsumgebung wurde hier nicht vollständig gestartet. Zur normalen Einrichtung `npm install` laut README verwenden.
