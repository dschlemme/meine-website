export class PricingError extends Error {}
export interface VehiclePricing { id: string; baseWeekdayCents: number; weekendSurchargeCents: number; depositCents: number }
export interface KmPackage { id: string; name: string; kmPerDay: number | null; unlimited: boolean; pricePerDayCents: number; extraKmCents: number }
export interface Extra { code: string; name: string; pricingMode: 'per_day' | 'per_booking' | 'per_km'; priceCents: number }
export interface PriceRule { name: string; validFrom: string; validUntil: string; multiplier: number; priority: number; vehicleId?: string | null; minDays?: number | null }
export interface DurationDiscount { minDays: number; percent: number }
const localDate = (d: Date) => { const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Berlin', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(d); const get = (t: string) => parts.find(p => p.type === t)!.value; return `${get('year')}-${get('month')}-${get('day')}`; };
export function calculateQuote({ vehicle, kmPackage, extras, start, end, rules = [], discounts = [] }: { vehicle: VehiclePricing; kmPackage: KmPackage; extras: Extra[]; start: Date; end: Date; rules?: PriceRule[]; discounts?: DurationDiscount[] }) {
 const duration = end.getTime() - start.getTime();
 if (!Number.isFinite(duration) || duration <= 0) throw new PricingError('Rückgabe muss nach der Abholung liegen.');
 // 24-Stunden-Tarif, 60 Minuten Kulanz nach dem ersten Miettag; lokale Berliner Tarifdaten.
 const days = Math.max(1, Math.ceil((duration - 3600000) / 86400000));
 if (days > 366) throw new PricingError('Maximal 366 Miettage möglich.');
 const dayLines = Array.from({ length: days }, (_, i) => {
  const date = localDate(new Date(start.getTime() + i * 86400000));
  const weekday = new Date(date + 'T12:00:00Z').getUTCDay(); const weekend = weekday === 0 || weekday >= 5;
  const rule = rules.filter(r => (!r.vehicleId || r.vehicleId === vehicle.id) && (!r.minDays || days >= r.minDays) && (!r.validFrom || date >= r.validFrom) && (!r.validUntil || date < r.validUntil)).sort((a,b) => b.priority-a.priority)[0];
  return { date, label: rule?.name ?? (weekend ? 'Wochenende' : 'Tagestarif'), cents: Math.round((vehicle.baseWeekdayCents + (weekend ? vehicle.weekendSurchargeCents : 0)) * (rule?.multiplier ?? 1)) };
 });
 const rentalSubtotalCents = dayLines.reduce((n,d) => n+d.cents,0);
 const discount = discounts.filter(d => days >= d.minDays).sort((a,b) => b.minDays-a.minDays)[0];
 const durationDiscount = discount ? { percent: discount.percent, cents: Math.round(rentalSubtotalCents * discount.percent / 100) } : null;
 const includedKm = kmPackage.unlimited ? null : days * (kmPackage.kmPerDay ?? 0);
 const kmPackageCents = days * kmPackage.pricePerDayCents;
 const extraLines = extras.map(x => { if (x.pricingMode === 'per_km') throw new PricingError('Extras pro Kilometer benötigen eine gesonderte Kilometerangabe.'); return { code: x.code, name: x.name, cents: x.priceCents * (x.pricingMode === 'per_day' ? days : 1) }; });
 const totalCents = rentalSubtotalCents - (durationDiscount?.cents ?? 0) + kmPackageCents + extraLines.reduce((n,x) => n+x.cents,0);
 if (!Number.isSafeInteger(totalCents) || totalCents < 0) throw new PricingError('Ungültige Tarifdaten.');
 const downPaymentCents = Math.round(totalCents * 0.3);
 return { days, dayLines, rentalSubtotalCents, durationDiscount, includedKm, kmPackageCents, extras: extraLines, totalCents, taxRatePercent: 19, taxIncludedCents: Math.round(totalCents * 19 / 119), downPaymentCents, dueAtBookingCents: downPaymentCents, dueAtPickupCents: totalCents-downPaymentCents, depositCents: vehicle.depositCents };
}
export type Quote = ReturnType<typeof calculateQuote>;
export function calculateReturnCharges(p: { startOdometerKm: number; endOdometerKm: number; includedKm: number | null; extraKmCents: number; fuelStartPercent: number; fuelEndPercent: number; tankCapacityLiters: number; fuelPricePerLiterCents: number; refuelServiceFeeCents: number; plannedEnd: Date; actualEnd: Date; lateFeePerStartedHourCents: number }) {
 const charges: { type: string; cents: number }[] = [];
 const km = p.includedKm === null ? 0 : Math.max(0,p.endOdometerKm-p.startOdometerKm-p.includedKm);
 if (km) charges.push({ type: 'extra_km', cents: km*p.extraKmCents });
 const fuel = Math.max(0,p.fuelStartPercent-p.fuelEndPercent);
 if (fuel) charges.push({ type: 'fuel', cents: Math.round(fuel/100*p.tankCapacityLiters*p.fuelPricePerLiterCents)+p.refuelServiceFeeCents });
 const late = Math.max(0,Math.ceil((p.actualEnd.getTime()-p.plannedEnd.getTime())/3600000));
 if (late) charges.push({ type: 'late_return', cents: late*p.lateFeePerStartedHourCents });
 return charges;
}
