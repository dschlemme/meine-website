import assert from 'node:assert/strict';
import { calculateQuote, calculateReturnCharges, PricingError, type Extra, type KmPackage, type VehiclePricing } from './pricing';

const vehicle: VehiclePricing = { id: 'v1', baseWeekdayCents: 80_000, weekendSurchargeCents: 20_000, depositCents: 500_000 };
const km: KmPackage = { id: 'k1', name: '200 km/Tag', kmPerDay: 200, unlimited: false, pricePerDayCents: 5_000, extraKmCents: 300 };
const gopro: Extra = { code: 'gopro', name: 'GoPro-Paket', pricingMode: 'per_day', priceCents: 3_000 };
const delivery: Extra = { code: 'delivery', name: 'Lieferung', pricingMode: 'per_booking', priceCents: 15_000 };

// Do 05.11.2026 10:00 → So 08.11.2026 10:00 (Berlin, UTC+1) = Do, Fr, Sa
const start = new Date('2026-11-05T09:00:00Z');
const end = new Date('2026-11-08T09:00:00Z');

// 1) Basisfall: 80.000 + 100.000 + 100.000 = 280.000; KM 15.000; Extras 9.000 + 15.000
let q = calculateQuote({ vehicle, kmPackage: km, extras: [gopro, delivery], start, end });
assert.equal(q.days, 3);
assert.equal(q.rentalSubtotalCents, 280_000);
assert.equal(q.includedKm, 600);
assert.equal(q.totalCents, 319_000);
assert.equal(q.taxIncludedCents, 50_933);
assert.equal(q.downPaymentCents, 95_700);
assert.equal(q.dueAtPickupCents, 223_300);
assert.equal(q.depositCents, 500_000);

// 2) Saisonregel (+50 % am Do 05.11.)
q = calculateQuote({
  vehicle, kmPackage: km, extras: [], start, end,
  rules: [{ name: 'Event', validFrom: '2026-11-05', validUntil: '2026-11-06', multiplier: 1.5, priority: 1 }],
});
assert.equal(q.dayLines[0].cents, 120_000);
assert.equal(q.rentalSubtotalCents, 320_000);

// 3) Mengenrabatt
q = calculateQuote({
  vehicle, kmPackage: km, extras: [], start, end: new Date('2026-11-12T09:00:00Z'),
  discounts: [{ minDays: 3, percent: 5 }, { minDays: 7, percent: 10 }],
});
assert.equal(q.days, 7);
assert.equal(q.durationDiscount?.percent, 10);

// 4) Kulanz: +30 Min. = 3 Tage, +90 Min. = 4 Tage
assert.equal(calculateQuote({ vehicle, kmPackage: km, extras: [], start, end: new Date(end.getTime() + 30 * 60_000) }).days, 3);
assert.equal(calculateQuote({ vehicle, kmPackage: km, extras: [], start, end: new Date(end.getTime() + 90 * 60_000) }).days, 4);

// 5) Unbegrenzte Kilometer
q = calculateQuote({ vehicle, kmPackage: { ...km, unlimited: true, kmPerDay: null }, extras: [], start, end });
assert.equal(q.includedKm, null);

// 6) Ungültiger Zeitraum
assert.throws(() => calculateQuote({ vehicle, kmPackage: km, extras: [], start, end: start }), PricingError);

// 7) Rückgabe-Nachberechnung
const charges = calculateReturnCharges({
  startOdometerKm: 10_000, endOdometerKm: 10_750, includedKm: 600, extraKmCents: 300,
  fuelStartPercent: 100, fuelEndPercent: 50, tankCapacityLiters: 70, fuelPricePerLiterCents: 220, refuelServiceFeeCents: 2_500,
  plannedEnd: end, actualEnd: new Date(end.getTime() + 2 * 3_600_000), lateFeePerStartedHourCents: 10_000,
});
assert.deepEqual(charges.map((c) => [c.type, c.cents]), [['extra_km', 45_000], ['fuel', 10_200], ['late_return', 20_000]]);

console.log('Alle Pricing-Tests bestanden.');
