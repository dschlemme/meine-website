import { useEffect, useState } from 'react';
import BookingFunnel from './components/BookingFunnel';
import type { Catalog } from './types';
export default function App() {
 const [catalog, setCatalog] = useState<Catalog>(); const [error, setError] = useState(''); const [id, setId] = useState('');
 useEffect(() => { const c = new AbortController(); fetch('/api/catalog', { signal: c.signal }).then(async r => { const b = await r.json(); if (!r.ok) throw new Error(b.error); setCatalog(b); setId(b.vehicles[0]?.id ?? ''); }).catch(e => { if (e.name !== 'AbortError') setError(e.message || 'Katalog konnte nicht geladen werden.'); }); return () => c.abort(); }, []);
 const vehicle = catalog?.vehicles.find(v => v.id === id);
 return <main><header className="border-b bg-white px-6 py-6"><div className="mx-auto max-w-5xl"><p className="text-xs uppercase tracking-widest">Schlemme Performance</p><p className="mt-2 text-xl font-semibold">Ihr Fahrerlebnis beginnt hier.</p></div></header>
 {error && <p role="alert" className="mx-auto max-w-5xl p-6 text-red-700">{error}</p>}
 {!catalog && !error && <p className="p-6">Fahrzeuge werden geladen …</p>}
 {catalog && <div className="mx-auto max-w-5xl px-6 pt-6"><p className="mb-4 text-sm">{catalog.demo ? 'Demomodus · Beispielpreise und simulierte Verfügbarkeit.' : 'Live-Preise und Verfügbarkeit aus der Datenbank.'} Dies ist eine unverbindliche Kalkulation; es wird keine Buchung angelegt.</p><label>Fahrzeug <select className="ml-3 rounded border p-2" value={id} onChange={e => setId(e.target.value)}>{catalog.vehicles.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</select></label>{!vehicle && <p>Keine aktiven Fahrzeuge vorhanden.</p>}</div>}
 {vehicle && catalog && <BookingFunnel key={vehicle.id} vehicle={vehicle} kmPackages={vehicle.kmPackages} extras={catalog.extras}/>}</main>;
}
