
import { useEffect, useMemo, useState } from 'react';
import type { Quote } from '@/lib/pricing';

interface Props {
  vehicle: { id: string; name: string };
  kmPackages: { id: string; name: string; pricePerDayCents: number; extraKmCents: number }[];
  extras: { code: string; name: string; hint: string }[];
}

const eur = (cents: number) =>
  new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(cents / 100);

export default function BookingFunnel({ vehicle, kmPackages, extras }: Props) {
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [kmPackageId, setKmPackageId] = useState(kmPackages[0]?.id ?? '');
  const [selected, setSelected] = useState<string[]>([]);
  const [state, setState] = useState<
    | { status: 'idle' }
    | { status: 'loading' }
    | { status: 'error'; message: string }
    | { status: 'ok'; available: boolean; quote: Quote }
  >({ status: 'idle' });

  const ready = useMemo(() => Boolean(start && end && kmPackageId), [start, end, kmPackageId]);

  // Echtzeit-Kalkulation: debounced, mit Abbruch veralteter Requests
  useEffect(() => {
    if (!ready) return setState({ status: 'idle' });
    const ctrl = new AbortController();
    setState({ status: 'loading' });

    const timer = setTimeout(async () => {
      try {
        const res = await fetch('/api/quote', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            vehicleId: vehicle.id,
            kmPackageId,
            extraCodes: selected,
            start: new Date(start).toISOString(),
            end: new Date(end).toISOString(),
          }),
          signal: ctrl.signal,
        });
        const body = await res.json();
        if (!res.ok) return setState({ status: 'error', message: body.error ?? 'Berechnung fehlgeschlagen.' });
        setState({ status: 'ok', available: body.available, quote: body.quote });
      } catch (e) {
        if ((e as Error).name !== 'AbortError') setState({ status: 'error', message: 'Verbindungsfehler.' });
      }
    }, 300);

    return () => { clearTimeout(timer); ctrl.abort(); };
  }, [ready, start, end, kmPackageId, selected, vehicle.id]);

  const toggleExtra = (code: string) =>
    setSelected((s) => (s.includes(code) ? s.filter((c) => c !== code) : [...s, code]));

  const q = state.status === 'ok' ? state.quote : null;
  const pkg = kmPackages.find((p) => p.id === kmPackageId);

  return (
    <section className="mx-auto grid max-w-5xl gap-8 p-6 md:grid-cols-[1fr_380px]">
      <div className="space-y-6">
        <h1 className="text-3xl font-semibold">{vehicle.name} mieten</h1>

        <div className="grid gap-4 sm:grid-cols-2">
          <label className="grid gap-1 text-sm">Abholung
            <input type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)}
              className="rounded-lg border p-2" />
          </label>
          <label className="grid gap-1 text-sm">Rückgabe
            <input type="datetime-local" value={end} min={start} onChange={(e) => setEnd(e.target.value)}
              className="rounded-lg border p-2" />
          </label>
        </div>

        <fieldset className="space-y-2">
          <legend className="font-medium">Kilometerpaket</legend>
          {kmPackages.map((p) => (
            <label key={p.id} className="flex items-center justify-between rounded-lg border p-3">
              <span className="flex items-center gap-2">
                <input type="radio" name="km" checked={kmPackageId === p.id} onChange={() => setKmPackageId(p.id)} />
                {p.name}
              </span>
              <span className="text-sm text-neutral-500">
                {p.pricePerDayCents ? `+ ${eur(p.pricePerDayCents)}/Tag` : 'inklusive'} · Mehr-km {eur(p.extraKmCents)}
              </span>
            </label>
          ))}
        </fieldset>

        <fieldset className="space-y-2">
          <legend className="font-medium">Extras</legend>
          {extras.map((x) => (
            <label key={x.code} className="flex items-center justify-between rounded-lg border p-3">
              <span className="flex items-center gap-2">
                <input type="checkbox" checked={selected.includes(x.code)} onChange={() => toggleExtra(x.code)} />
                {x.name}
              </span>
              <span className="text-sm text-neutral-500">{x.hint}</span>
            </label>
          ))}
        </fieldset>
      </div>

      <aside className="h-fit space-y-3 rounded-2xl border p-5 shadow-sm md:sticky md:top-6" aria-live="polite">
        <h2 className="text-lg font-medium">Ihre Kalkulation</h2>

        {state.status === 'idle' && <p className="text-sm text-neutral-500">Zeitraum wählen, um den Preis zu sehen.</p>}
        {state.status === 'loading' && <p className="text-sm text-neutral-500">Berechne …</p>}
        {state.status === 'error' && <p className="text-sm text-red-600">{state.message}</p>}

        {q && state.status === 'ok' && (
          <>
            {!state.available && (
              <p className="rounded-lg bg-red-50 p-2 text-sm text-red-700">
                Für diesen Zeitraum ist das Fahrzeug leider nicht verfügbar.
              </p>
            )}

            <ul className="space-y-1 text-sm">
              {q.dayLines.map((d) => (
                <li key={d.date} className="flex justify-between">
                  <span>{new Date(d.date).toLocaleDateString('de-DE')} · {d.label}</span>
                  <span>{eur(d.cents)}</span>
                </li>
              ))}
              {q.durationDiscount && (
                <li className="flex justify-between text-green-700">
                  <span>Mengenrabatt {q.durationDiscount.percent} %</span>
                  <span>− {eur(q.durationDiscount.cents)}</span>
                </li>
              )}
              <li className="flex justify-between">
                <span>{pkg?.name} ({q.includedKm ?? '∞'} km inkl.)</span>
                <span>{eur(q.kmPackageCents)}</span>
              </li>
              {q.extras.map((x) => (
                <li key={x.code} className="flex justify-between"><span>{x.name}</span><span>{eur(x.cents)}</span></li>
              ))}
            </ul>

            <div className="space-y-1 border-t pt-3 text-sm">
              <div className="flex justify-between text-base font-semibold"><span>Gesamt</span><span>{eur(q.totalCents)}</span></div>
              <div className="flex justify-between text-neutral-500"><span>inkl. {q.taxRatePercent} % MwSt.</span><span>{eur(q.taxIncludedCents)}</span></div>
              <div className="flex justify-between"><span>Anzahlung bei Buchung</span><span>{eur(q.dueAtBookingCents)}</span></div>
              <div className="flex justify-between"><span>Rest bei Übergabe</span><span>{eur(q.dueAtPickupCents)}</span></div>
              <div className="flex justify-between text-neutral-500"><span>Kaution (Kartenreservierung)</span><span>{eur(q.depositCents)}</span></div>
            </div>

            <button disabled title="Verifizierung und Buchung sind noch nicht angebunden."
              className="w-full rounded-xl bg-black py-3 font-medium text-white disabled:opacity-40">
              Online-Buchung folgt
            </button>
          </>
        )}
      </aside>
    </section>
  );
}
