# Schlemme Performance — Vite + React + Netlify Functions

Startfähige Mietkalkulation auf Basis deiner Dateien. Preisberechnung und Verfügbarkeit sind enthalten. Verifizierung, Zahlung, Login und das Speichern verbindlicher Buchungen sind noch nicht implementiert. Der entsprechende Button ist deshalb deaktiviert.

## Lokal starten

Node.js 22.12 oder neuer installieren. Im Projektordner:

```sh
npm install
cp .env.example .env
npm run dev
```

http://localhost:8888 öffnen. Mit `DEMO_MODE=true` funktioniert die Kalkulation ohne Datenbank. Die Verfügbarkeit ist dabei simuliert und immer positiv. `npm run dev:ui` startet nur das Frontend; für die API immer `npm run dev` verwenden. Netlify CLI kann beim ersten Start die Anmeldung am Netlify-Konto verlangen.

```sh
npm test
npm run build
```

## Wo liegen deine Dateien?

| Datei | Ziel / Anpassung |
| --- | --- |
| BookingFunnel.tsx | `src/components/BookingFunnel.tsx`; bereits eingefügt, Button bis zur Implementierung deaktiviert |
| pricing.test.ts | `src/lib/pricing.test.ts`; unverändert eingefügt |
| pricing.ts | `src/lib/pricing.ts`; fehlende Implementierung anhand der Tests ergänzt |
| booking-repo.ts | `server/booking-repo.ts`; Imports, Pool und Auswahlprüfung angepasst |
| route.ts | durch `netlify/functions/quote.ts` ersetzt; Original in `docs/route-nextjs-original.ts.txt` |
| schema.sql | `database/schema.sql`; unverändert eingefügt |
| ARCHITEKTUR.md | `docs/ARCHITEKTUR-original.md`; ursprünglicher Entwurf, kein Nachweis implementierter Funktionen |

Zusätzlich: `src/App.tsx` lädt Fahrzeuge, Pakete und Extras über `netlify/functions/catalog.ts`. `src/main.tsx` und `index.html` starten React. Tailwind ist eingerichtet; `@/` zeigt auf `src/`. Serverdateien gehören niemals unter `src/` in den Browsercode. Die Next.js-Datei `route.ts` nicht zusätzlich als Vite-Route einfügen.

## Datenbank einrichten

Erforderlich ist **PostgreSQL**, keine MySQL-/MariaDB-Datenbank. Supabase ist eine mögliche PostgreSQL-Plattform; selbst gehostetes Supabase auf einem IONOS-Server ist eine andere Betriebsvariante. Für dieses Projekt genügt PostgreSQL ohne weitere Supabase-Dienste.

1. Neue, leere PostgreSQL-Datenbank anlegen. Bei Supabase im SQL Editor zunächst `database/schema.sql` ausführen. Das Schema ist für eine einmalige Einrichtung gedacht, nicht für wiederholte Ausführung auf einer bestehenden Datenbank.
2. Optional `database/seed.sql` ausführen und die Beispielpreise vor Livebetrieb durch echte Daten ersetzen.
3. **Bei Supabase zusätzlich `database/supabase-security.sql` ausführen**, bevor echte Kundendaten gespeichert werden. Es aktiviert RLS und sperrt direkten Zugriff der öffentlichen API-Rollen auf die Tabellen im public-Schema. Nur für ein neues, dediziertes Projekt gedacht. Die Netlify Functions greifen per PostgreSQL-Verbindung zu.
4. Für Supabase im Connect-Dialog die **Transaction-pooler**-Verbindungsadresse kopieren. Passwort in der URL korrekt URL-kodieren. Bei IONOS den extern erreichbaren PostgreSQL-Host, Datenbank, Port und Benutzer verwenden; `btree_gist` und `pgcrypto` müssen verfügbar sein, TLS und externer Zugriff müssen erlaubt sein. Normales IONOS-Webhosting mit ausschließlich MySQL reicht nicht.
5. In `.env` `DEMO_MODE=false` und `DATABASE_URL=postgresql://...` setzen. Auf Netlify dieselben Werte als Umgebungsvariablen mit Zugriff für Functions hinterlegen. Keine Zugangsdaten in Git speichern und kein `VITE_` vor Datenbankvariablen verwenden.
6. Der Server prüft TLS-Zertifikate. Falls der Anbieter eine eigene CA verwendet, deren PEM-Inhalt in `DATABASE_CA_CERT` hinterlegen. SSL-Optionen wie `sslmode`/`sslrootcert` aus der Verbindungs-URL entfernen, damit die explizite TLS-Konfiguration nicht überschrieben wird. Zertifikatsprüfung nicht deaktivieren.

## Auf Netlify veröffentlichen

Projekt in ein Git-Repository hochladen, bei Netlify importieren und diesen Projektordner als Basis wählen. Die mitgelieferte `netlify.toml` konfiguriert:

- Build: `npm run build`
- Veröffentlichungsordner: `dist`
- Functions: `netlify/functions`
- `/api/quote` und `/api/catalog` werden an die Functions weitergeleitet.

Für einen bewussten Demo-Deploy `DEMO_MODE=true` setzen. Für echte Daten `DEMO_MODE=false`, `DATABASE_URL` und ggf. `DATABASE_CA_CERT` setzen; danach neu deployen. Nur `dist` per Drag-and-drop hochzuladen reicht nicht, da dabei die Backend-Functions fehlen. Die IONOS-Domain kann später per DNS auf Netlify zeigen; das Datenbankhosting bleibt davon unabhängig.

## Tarifannahmen und Grenzen

Die fehlende Preislogik wurde aus den mitgelieferten Tests rekonstruiert: Miettage sind 24 Stunden mit 60 Minuten Kulanz, Fr–So haben Wochenendzuschlag, Tarifdaten verwenden Europe/Berlin, Saisonzeiträume sind am Ende exklusiv, höchste Regelpriorität gewinnt, der Rabatt mit größter erfüllter Mindestdauer gilt nur auf den Mietpreis. 19 % MwSt., 30 % Anzahlung. Diese Beispielregeln vor Betrieb fachlich bestätigen. Ein voller Miettag bleibt auch bei kurzen Mieten fällig. Kilometerbasierte Extras werden nicht angeboten und von der Quote abgelehnt.

Verfügbarkeit ist eine Momentaufnahme, keine Reservierung. Das Originalschema sperrt auch abgelaufene Holds per Exclusion Constraint; vor Implementierung des Buchungsabschlusses muss ein serverseitiger Prozess abgelaufene Holds auf cancelled setzen. Der Originalcode addiert Puffer auf beiden Vergleichsseiten; dadurch können zwischen Mieten insgesamt sechs Stunden Abstand nötig sein. Datenbankmigrationen, ein eingeschränktes DB-Servicekonto, Schutz vor automatisierten Massenanfragen und der vollständige Checkout sind vor einem öffentlichen Buchungsbetrieb gesondert umzusetzen.

## Offizielle Referenzen

- https://docs.netlify.com/build/frameworks/framework-setup-guides/vite/
- https://docs.netlify.com/build/functions/get-started/
- https://supabase.com/docs/guides/database/connecting-to-postgres
