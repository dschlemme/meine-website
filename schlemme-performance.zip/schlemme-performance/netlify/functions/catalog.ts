import { pool, demo, requireDatabase } from '../../server/db';
import { catalog } from '../../server/demo';
import { json } from '../../server/http';
export default async (req: Request) => {
 if (req.method !== 'GET') return json({ error: 'Nur GET erlaubt.' },405);
 if (demo) return json(catalog);
 try { requireDatabase();
 const [v,k,e] = await Promise.all([pool.query("SELECT id, make, model, variant FROM vehicles WHERE vehicle_status = 'active' ORDER BY make,model"),pool.query('SELECT * FROM km_packages ORDER BY price_per_day_cents'),pool.query("SELECT * FROM extras WHERE active AND pricing_mode != 'per_km' ORDER BY name")]);
 return json({ demo: false, vehicles: v.rows.map(x => ({ id: x.id, name: [x.make,x.model,x.variant].filter(Boolean).join(' '), kmPackages: k.rows.filter(p => p.vehicle_id === x.id).map(p => ({ id: p.id, name: p.name, pricePerDayCents: Number(p.price_per_day_cents), extraKmCents: Number(p.extra_km_cents) })) })), extras: e.rows.map(x => ({ code: x.code, name: x.name, hint: `${(Number(x.price_cents)/100).toFixed(2)} € / ${x.pricing_mode === 'per_day' ? 'Tag' : 'Buchung'}` })) });
 } catch { console.error('Catalog request failed'); return json({ error: 'Datenbank nicht erreichbar oder Serverkonfiguration unvollständig.' },503); }
};
