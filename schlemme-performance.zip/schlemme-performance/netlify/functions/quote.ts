import { z } from 'zod';
import { calculateQuote, PricingError } from '../../src/lib/pricing';
import { isVehicleAvailable, loadPricingData } from '../../server/booking-repo';
import { demo, requireDatabase } from '../../server/db';
import * as sample from '../../server/demo';
import { json } from '../../server/http';
const schema = z.object({ vehicleId: z.string().uuid(), kmPackageId: z.string().uuid(), start: z.string().datetime({ offset: true }), end: z.string().datetime({ offset: true }), extraCodes: z.array(z.string().max(50)).max(20).default([]) });
export default async (req: Request) => {
 if (req.method !== 'POST') return json({ error: 'Nur POST erlaubt.' },405);
 const parsed = schema.safeParse(await req.json().catch(() => null));
 if (!parsed.success) return json({ error: 'Ungültige Anfrage.' },400);
 const p = parsed.data; const start = new Date(p.start); const end = new Date(p.end);
 if (start.getTime() < Date.now()) return json({ error: 'Abholung liegt in der Vergangenheit.' },422);
 try {
  if (!demo) requireDatabase();
  const data = demo ? (p.vehicleId === sample.vehicle.id && p.kmPackageId === sample.kmPackage.id && p.extraCodes.every(code => sample.extras.some(x => x.code === code)) ? { vehicle: sample.vehicle, kmPackage: sample.kmPackage, extras: sample.extras.filter(x => p.extraCodes.includes(x.code)) } : null) : await loadPricingData(p.vehicleId,p.kmPackageId,[...new Set(p.extraCodes)]);
  if (!data) return json({ error: 'Fahrzeug, Kilometerpaket oder Extras nicht gefunden.' },404);
  const quote = calculateQuote({ ...data, start, end });
  const available = demo ? true : await isVehicleAvailable(p.vehicleId,start,end);
  return json({ available, quote });
 } catch (e) { if (e instanceof PricingError) return json({ error: e.message },422); console.error('Quote request failed'); return json({ error: 'Datenbank nicht erreichbar oder Serverkonfiguration unvollständig.' },503); }
};
