# Sportwagenvermietung – Architektur & Tech-Stack (Entwurf v0.1)

## 1. Gesamtbild

```
                ┌──────────────────────────────────────────────┐
                │                  Next.js 15                  │
                │  (App Router, React Server Components, TS)  │
                ├──────────────┬───────────────┬───────────────┤
                │ Buchungsseite│ Kundenportal  │ Backoffice    │
                │ (öffentlich) │ (Login)       │ (Rollen)      │
                └──────┬───────┴───────┬───────┴───────┬───────┘
                       │  Route Handlers / Server Actions (Zod-validiert)
          ┌────────────┴───────────────┴───────────────┴────────────┐
          │                  Domain-Services (TypeScript)           │
          │  Pricing · Availability · Booking · Payment · Contract  │
          │  Inspection · Invoice · Screening · Telematics          │
          └───┬──────────┬───────────┬────────────┬─────────────┬───┘
              │          │           │            │             │
         PostgreSQL   Redis/Queue  Object Store  Externe APIs   Worker
         (Prisma/     (BullMQ:     (S3/R2:       Stripe/Mollie  (Mails, PDFs,
          Drizzle)     Jobs, Locks) Fotos, PDFs)  Screening      Mahnungen,
                                                  Signatur       Webhooks)
                                                  Telematik
```

## 2. Tech-Stack

| Bereich | Empfehlung | Begründung |
|---|---|---|
| Frontend | Next.js 15, React, TypeScript, TailwindCSS, shadcn/ui | Ein Codebase für Buchung, Portal, Backoffice, Mobile Web |
| Backend | Next.js Route Handlers + separater Node.js-Worker (BullMQ) | Einfacher Start, Jobs (PDF, Mails, Mahnwesen) getrennt |
| DB | PostgreSQL 16 | Exclusion Constraints verhindern Doppelbuchungen auf DB-Ebene |
| ORM | Prisma oder Drizzle | Typsicherheit; Constraints per SQL-Migration |
| Auth | Auth.js oder Clerk, Rollen: customer / staff / admin | Backoffice strikt getrennt |
| Payment | Stripe (Pre-Auth/Kautionsblockade, Payment Intents) oder Mollie | Stripe: `capture_method=manual` für Kaution |
| Identitätsprüfung | Stripe Identity / Veriff / Onfido / HyghCheck (je nach Vertrag) | Ausweis + Führerschein + Liveness |
| Signatur | Fortgeschrittene E-Signatur (FES, eIDAS Art. 26) via Anbieter (z. B. Skribble, Yousign, DocuSign) oder eigene Lösung mit Audit-Trail | Rechtssicherheit, Zeitstempel, Hash |
| PDF | Playwright/Puppeteer (HTML → PDF/A) oder react-pdf | GoBD: unveränderbare Archivierung |
| Dateien | S3-kompatibel (Cloudflare R2 / AWS S3 EU), verschlüsselt | Fotos, Ausweise, Verträge |
| Hosting | EU-Region (Frankfurt), z. B. Vercel + Neon/Supabase oder Hetzner | DSGVO |
| Telematik | Adapter-Schicht (Interface), Anbieter später (z. B. Invers, Spiderfleet) | Anbieterunabhängig |
| Monitoring | Sentry, Logtail, Uptime-Check | Betrieb |

## 3. Module & Verantwortlichkeiten

1. **Availability** – prüft Fahrzeug frei im Zeitraum inkl. Puffer (Reinigung/Wartung). Sperre per `tstzrange` + Exclusion Constraint. Beim Checkout 15 Min. Soft-Hold (Status `hold`).
2. **Pricing** – reine, deterministische Funktion (siehe `pricing.ts`). Serverseitig maßgeblich, Client zeigt nur Vorschau. Preis-Snapshot wird in der Buchung gespeichert.
3. **Booking** – Zustandsautomat: `hold → pending_payment → confirmed → contract_signed → active → returned → settled` (+ `cancelled`, `no_show`).
4. **Onboarding/Screening** – Upload, Provider-Check, Ergebnis (`verified/rejected/manual_review`), Blacklist-Abgleich, Mindestalter/Führerscheindauer pro Fahrzeugklasse.
5. **Payment** – Anzahlung oder Vollzahlung; Kaution als Pre-Auth (Hinweis: Authorizations laufen je nach Karte nach ca. 7 Tagen ab, daher bei langen Mieten Re-Auth-Strategie); Webhooks idempotent verarbeiten.
6. **Schuldenbuch** – `charges`-Tabelle: Nachforderungen (Überkilometer, Tank, Verspätung, Schaden) mit Status offen/eingezogen/storniert; Einzug aus Kaution oder per Zahlungslink.
7. **Vertrag** – Template + Daten → PDF/A → Signatur (Mieter am Gerät) → Hash + Audit-Trail → Archiv.
8. **Inspection (Check-in/-out)** – geführter Ablauf mit Pflichtfotos, interaktivem Schadensschema (SVG), Unterschriften beider Parteien, Diff zur vorherigen Inspection.
9. **Invoice** – fortlaufende Nummernkreise, unveränderlich (Storno + Neuausstellung statt Änderung), PDF/A, 10 Jahre Aufbewahrung (GoBD).
10. **CRM/Dashboard** – Kundenhistorie, Schäden, Blacklist, Auslastung, offene Kautionen, Umsatz.
11. **Telematik-Adapter** – Interface `TelematicsProvider` (Position, Fahrtenbuch, Immobilizer). Fern-Wegfahrsperre nur mit Vier-Augen-Freigabe und vertraglicher Grundlage.

## 4. Kernprinzipien

- **Preis-Snapshot**: Jede Buchung speichert die Preisaufschlüsselung (JSONB) – spätere Tarifänderungen verändern keine alten Buchungen.
- **Geld in Cent (Integer)**, nie Float.
- **Doppelbuchungsschutz** in der Datenbank, nicht nur in der Anwendung.
- **Audit-Log** für alle sensiblen Aktionen (Signatur, Kaution, Wegfahrsperre, Datenzugriff auf Ausweise).
- **DSGVO**: Ausweisbilder verschlüsselt, kurze Aufbewahrung nach erfolgreicher Prüfung, Löschkonzept, AV-Verträge mit Dienstleistern.
- **Idempotenz** bei Webhooks und Zahlungsaktionen.

## 5. Roadmap (Vorschlag)

| Phase | Inhalt |
|---|---|
| 1 (MVP) | Flotte, Verfügbarkeit, Preisrechner, Buchung, Stripe-Zahlung, Kaution, Backoffice-Basis |
| 2 | Onboarding/Screening, Vertrag + Signatur, Rechnungen |
| 3 | Check-in/-out-App, Schadensverwaltung, Schuldenbuch |
| 4 | CRM, Dashboard, Telematik, Blacklist |

## 6. Rechtlich zu klären (kein Rechtsrat)

- Vertragsklauseln, AGB, Haftungsreduzierung/Selbstbeteiligung, Versicherungsbedingungen
- Signaturniveau (FES reicht meist; QES nur bei Bedarf)
- Umsatzsteuer-Behandlung, Rechnungsangaben je Land
- DSGVO-Konzept für Ausweisdaten, Telematik-Tracking (Einwilligung/Information)
